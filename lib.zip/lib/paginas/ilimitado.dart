import 'package:flutter/material.dart';

import '../widgets/botoes.dart';
import '../widgets/meutexto.dart';

class Ilimitado extends StatefulWidget {
  const Ilimitado({super.key});

  @override
  State<Ilimitado> createState() => _IlimitadoState();
}

class _IlimitadoState extends State<Ilimitado> {
  int vidas = 5;
  int qtdPergunta = 1;
  String pergunta = "Pergunta";
  var resposta = ["resposta1", "resposta2", "resposta3", "resposta4", "resposta5"];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: MeuTexto(
            texto: "History.io",
            cor: Colors.white,
            tamanhoFonte: 20,
          ),
        ),
        body: Container(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
          alignment: Alignment.center,
          child: Column(
            children: [
              SizedBox(
                  height: 50
              ),
              Container(
                alignment: Alignment.center,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    MeuTexto(
                      texto: "Pergunta $qtdPergunta:",
                      tamanhoFonte: 20,
                    ),
                    SizedBox(height: 20),
                    MeuTexto(
                      texto: pergunta,
                      tamanhoFonte: 16,
                    ),
                  ],
                ),
              ),
              SizedBox(height:10),
              Align(
                alignment: Alignment.centerLeft,
                child: MeuTexto(
                  texto: "Vidas: $vidas",
                  tamanhoFonte: 20,
                ),
              ),
              SizedBox(height: 10),
              Container(
                padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.purple,
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    Botoes(resposta[0], onPressed: (){}),
                    SizedBox(height: 20),
                    Botoes(resposta[1], onPressed: (){}),
                    SizedBox(height: 20),
                    Botoes(resposta[2], onPressed: (){}),
                    SizedBox(height: 20),
                    Botoes(resposta[3], onPressed: (){}),
                    SizedBox(height: 20),
                    Botoes(resposta[4], onPressed: (){}),
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }
}
